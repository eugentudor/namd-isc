#!/bin/bash
sh ./wham_data_solv.sh
sh ./wham_fe.sh
perl ./sum_fe.pl
