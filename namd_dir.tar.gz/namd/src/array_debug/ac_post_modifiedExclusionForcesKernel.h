    AC_DEVICE(myQ, "post_modifiedexclusionforceskernel", forces, forceSize);
    AC_DEVICE(myQ, "post_modifiedexclusionforceskernel", energies_virials, energies_virials_SIZE);
